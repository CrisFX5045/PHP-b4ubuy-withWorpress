<!-- contact -->

<div class="col-5 justify-content-center">
    <div class="row">
        <h2>Contact</h2>
    </div>
    <div class="row">
        <label for="">Full name</label>
        <input type="text">
    </div>
    <div class="row">
        <label for="">Email</label>
        <input type="text">
    </div>
    <div class="row">
        <input type="submit" value="Message">
    </div>
</div>


<!-- contact -->