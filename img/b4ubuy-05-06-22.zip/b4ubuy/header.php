<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
    <title>WORDPRESS</title>
    
</head>

<body>
   <!-- container -->
    <div>
        <!-- header -->
     <header>

        <nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
    <a class="logo" href="#">B4 U BUY</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        
            <ul class="navbar-nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="reviews">Reviews</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">News</a>
                    </li>
                    <li class="nav-item">
                         <a class="nav-link" href="#">Forum</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact</a>
                    </li>
            </ul>
       
      </div> 
    </div>
  </nav>
        
    
     </header>
        <!-- header -->